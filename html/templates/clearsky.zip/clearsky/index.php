<?php defined( "_VALID_MOS" ) or die( "Direct Access to this location is not allowed." );?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php if ( $my->id ) { initEditor(); } ?>
<meta http-equiv="Content-Type" content="text/html;><?php echo _ISO; ?>" />
<?php mosShowHead(); ?>
<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/template_css.css\" type=\"text/css\"/>" ; ?><?php echo "<link rel=\"shortcut icon\" href=\"$GLOBALS[mosConfig_live_site]/images/favicon.ico\" />" ; ?>
<link href="css/template_css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.Stil1 {font-size: 10px}
-->
</style>
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table id="Tabel_01" width="960" height="600" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td style="background-image:url(<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/clearsky_01.gif" ?>); background-repeat:no-repeat; width:960px; height:113px;" valign="bottom">
		<table cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="28" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
			<td width="142" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/navigation_03.gif" ?>" alt="" /></td>
			<td width="11" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
			<td width="142" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/navigation_05.gif" ?>" alt="" /></td>
			<td width="11" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
			<td width="142" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/navigation_07.gif" ?>" alt="" /></td>
			<td width="12" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
			<td width="142" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/navigation_09.gif" ?>" alt="" /></td>
			<td width="11" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
			<td width="142" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/navigation_11.gif" ?>" alt="" /></td>
			<td width="177" height="15" align="center"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/nix.gif" ?>" alt="" /></td>
		</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td style="background-color:#003866; width:960px; height:12px;">&nbsp;</td>
	</tr>
	<tr>
		<td style="background-image:url(<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/clearsky_03.gif" ?>); background-repeat:no-repeat; width:960px; height:108px;">&nbsp;</td>
	</tr>
	<tr>
		<td style="width:960px; height:367px;">
		<?php //mosLoadModules ( 'user3' ); ?><!-- header nav -->
		<?php mosPathWay(); ?>
		<?php mosMainBody(); ?>
		<?php //mosLoadModules ( 'top' ); ?><!-- news flash -->
		<?php //mosLoadModules ( 'left' ); ?><!-- main nav -->
		<?php //mosLoadModules ( 'right' ); ?>
		<?php //mosLoadModules ( 'user4' ); ?>
		content</td>
	</tr>
	<tr>
		<td style="width:960px; height:367px;">
		<?php include_once('includes/footer.php'); ?>
		</td>
	</tr>
</table>
</body>
</html>